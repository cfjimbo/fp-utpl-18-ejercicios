
from random import randint

valores1=[]
valores2=[]

suma1 = 0
suma2 = 0

jugador1 = "Jugador1"
jugador2 = "Jugador2"

for i in range(5):

    valores1.append(randint(1,6))

    valores2.append(randint(1,6))

    suma1 = suma1 + valores1[i]

    suma2 = suma2 + valores2[i]

if(suma1 > suma2):

    print("Primer lugar " , jugador1 , " gano con " , suma1 , "puntos")
    print("Segundo lugar " , jugador2 , " se quedo" , suma2 , "puntos")

elif(suma1==suma2):

    print("Empate")

else:
    
    print("Primer lugar " , jugador2 , " gano con " , suma2 , "puntos")
    print("Segundo lugar " , jugador1 , " se quedo " , suma1 , "puntos")

input()