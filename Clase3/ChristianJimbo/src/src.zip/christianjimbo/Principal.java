/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package christianjimbo;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Principal {

    public static void main(String[] args) {
        ProgresionGeometrica p = new ProgresionGeometrica();
        Scanner s = new Scanner(System.in);

        p.Generarprogresion();
    }
}
