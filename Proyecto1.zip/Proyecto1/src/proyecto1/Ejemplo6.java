/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

import java.util.Scanner;

/**
 *
 * @author Salas
 */
class Ejemplo6 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String nombre = "Christian";
        String apellido = "Jimbo";   
        System.out.printf("Ingrese valorn para su Nombre");
        nombre = entrada.nextLine();
        System.out.printf("Ingrese valorn para su Apellido");
        apellido = entrada.next();
        
        System.out.printf("Su nombre es: %s\nSu apellido es:%s\n",
                nombre, apellido);
    }
}
