/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Salas
 */
class Ejemplo3 {
    public static void main(String[] args) {
        String mensaje1 = "Hola";
        String mensaje2 = "Mundo";
        // System.out.println(mensaje1+"\n"+mensaje2);
        System.out.printf("%s\n\t%s",mensaje1,mensaje2);
    }
}
